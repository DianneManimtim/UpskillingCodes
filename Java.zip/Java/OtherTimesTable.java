import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter 6, 7, or 8 for the Times Table: ");
        int input = scan.nextInt();

        switch (input){
            case 6: TimesTable(6);
            break;
            case 7: TimesTable(7);
            break;
            case 8: TimesTable(8);
            break;
            default: System.out.println("You do not enter 6, 7, or 8!");

        }
    }

    static void TimesTable(int val){
        for (int i = 1; i<=12; i++){
            System.out.println(val+" x "+i+" = "+val*i);
        }
    }
}
