package com.company;

public class Main {

    public static void main(String[] args) {
        int arrayNum[] = {1,2,3,4};

        changeArrayElement(arrayNum);

        for (int i = 0; i<arrayNum.length; i++){
            System.out.println(arrayNum[i]);
        }
    }

    static void changeArrayElement(int myArray[]){
        myArray[1] = 100;
    }
}
