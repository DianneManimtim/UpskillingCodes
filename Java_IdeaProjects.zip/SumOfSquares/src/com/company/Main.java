package com.company;

import java.lang.Math;

public class Main {

    public static void main(String[] args) {
        //getting the sum of the square of number 1 to 9:
        int temp =0;
        for (int i = 1; i<=9; i++){
            double val = Math.pow(i,2);
            temp += val;
        }

        System.out.println("The sum of the squares of number 1 to 9 is: "+temp);
    }
}
