package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Minutes per day: "+60*24);
        System.out.println("Seconds per day: "+60*60*24);

        System.out.println("Remainder of 5 divided by 2: "+5%2);

        System.out.println();
        System.out.println("Value of array:");
        int arrayNum[] = {1,2,3,4};

        for (int i = 0; i<arrayNum.length; i++){
            System.out.println(arrayNum[i]);
        }

        System.out.println();
        System.out.printf("5 x 1 = %d", 5*1);
        System.out.println();
        System.out.println("Multiplication of 5");
        for (int i = 1; i<13; i++){
            System.out.println("5 x "+ i + " = " + 5*i);
        }

        /**
         * 5 times table
         * with WHILE LOOP
         */
        System.out.println();
        System.out.println("Using WHILE LOOP");
        int count = 1;
        while(count < 13){
            System.out.println("5 x "+count+" = "+5*count);
            count++;
        }

        /**
         * Slide 59:
         */
        System.out.println();
        System.out.println("Odd or Even:");
        for (int i = 1; i<=10; i++){
            if (i%2 == 0){
                System.out.println(i+" is an even number.");
            }else {
                System.out.println(i+" is an even number.");
            }
        }

        /**
         * Slide no. 43:
         */
        System.out.println();
        int a,b,c;
        System.out.print("Enter 1st value: ");
        a = scan.nextInt();
        System.out.print("Enter 2nd value: ");
        b = scan.nextInt();
        System.out.print("Enter 3rd value: ");
        c = scan.nextInt();

        int sum = a+b+c;
        System.out.println("The sum of "+a+", "+b+", and "+c +" is: "+sum);
        System.out.println();

        /**
         * nested loop
         */
        System.out.println();
        for (int i = 0; i<5; i++){
            for (int j = 0; j<=i; j++){
                System.out.print("*");
            }
            System.out.println();
        }

        return;
    }
}
