package com.company;

/**
 * Animal class
 *
 * class to be accessed
 */
class Animal{
    private String name = "";      //fields
    private String species = "";
    private int age = 0;
    private double weight = 0;

    //constructor
    public Animal(String name, String speciesParam,int ageParam, double weightParam){
        this.name = name;
        this.species = speciesParam;
        this.age = ageParam;
        this.weight = weightParam;
    }

    public String printAnimal(){
        return this.name+" "+this.species+" "+this.age+" "+this.weight;
    }
}

/**
 * Main Class
 */
public class Main {

    public static void main(String[] args) {

        Animal a1 = new Animal("Pororo", "penguin", 1, 3.5);
        System.out.println(a1.printAnimal());

        String animal_name[] = {"Annie", "Dianne","Nicole","Shai","Ed"};
        String animal_species[] = {"specie1","specie2","specie3","specie4","specie5"};
        int patient_age[] = {12,23,34,45,56};
        float patient_weight[] = {98,87,76,65,54};

        for (int i = 0; i<5; i++){
            System.out.println(printAnimal(animal_name[i],animal_species[i],patient_age[i]));
            System.out.println(printAnimal(animal_name[i],animal_species[i],patient_age[i],patient_weight[i]));
            System.out.println();
        }

    }

    static String printAnimal(String myAnimalName, String myAnimalSpecies, int myPatientAge){
        return myAnimalName+" "+myAnimalSpecies+" "+myPatientAge;
    }

    static String printAnimal(String myAnimalName, String myAnimalSpecies, int myPatientAge, float myPatientWeight){
        return myAnimalName+" "+myAnimalSpecies+" "+myPatientAge+" "+myPatientWeight;
    }

}


