package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("Multiplication Table from 1 to 9:");
        for (int i= 1; i <= 9; i++){
            System.out.println();
            System.out.println("Multiplication of "+i);
            printMultiplicationTable(i);
        }

    }

    static void printMultiplicationTable(int val){
        for (int i = 1; i<=12; i++){
            System.out.println(val+" x "+i+" = "+val*i);
        }
    }
}
